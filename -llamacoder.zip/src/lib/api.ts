import { Post, Comment } from '../types';

// Mock data for demonstration
const mockPosts: Post[] = [
  {
    id: '1',
    imageUrl: 'https://picsum.photos/400/300?random=1',
    caption: 'Beautiful sunset at the beach! 🌅',
    altText: 'A colorful sunset over the ocean with waves',
    createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 minutes ago
    comments: [
      {
        id: 'c1',
        text: 'Amazing view! Where was this taken?',
        createdAt: new Date(Date.now() - 1000 * 60 * 2).toISOString(), // 2 minutes ago
      },
      {
        id: 'c2',
        text: 'Looks absolutely stunning! 😍',
        createdAt: new Date(Date.now() - 1000 * 60 * 1).toISOString(), // 1 minute ago
      }
    ]
  },
  {
    id: '2',
    imageUrl: 'https://picsum.photos/400/300?random=2',
    caption: 'Coffee and coding - perfect combination! ☕💻',
    altText: 'A laptop on a desk with a cup of coffee',
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
    comments: [
      {
        id: 'c3',
        text: 'My daily routine!',
        createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(), // 15 minutes ago
      }
    ]
  },
  {
    id: '3',
    imageUrl: 'https://picsum.photos/400/300?random=3',
    caption: 'Morning hike in the mountains 🏔️',
    altText: 'Mountain trail with green trees and blue sky',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
    comments: []
  }
];

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// In-memory storage for posts (simulates backend)
let posts = [...mockPosts];
let postIdCounter = 4;
let commentIdCounter = 4;

export async function getPosts(page: number = 1, limit: number = 5): Promise<Post[]> {
  await delay(500); // Simulate network delay
  
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  
  // Return posts in reverse chronological order (newest first)
  const sortedPosts = [...posts].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  return sortedPosts.slice(startIndex, endIndex);
}

export async function createPost(file: File, caption: string, altText: string): Promise<Post> {
  await delay(1000); // Simulate upload delay
  
  // Create object URL for the uploaded image
  const imageUrl = URL.createObjectURL(file);
  
  const newPost: Post = {
    id: postIdCounter.toString(),
    imageUrl,
    caption,
    altText,
    createdAt: new Date().toISOString(),
    comments: []
  };
  
  posts.push(newPost);
  postIdCounter++;
  
  return newPost;
}

export async function addComment(postId: string, text: string): Promise<Comment> {
  await delay(300); // Simulate network delay
  
  const newComment: Comment = {
    id: commentIdCounter.toString(),
    text,
    createdAt: new Date().toISOString()
  };
  
  const post = posts.find(p => p.id === postId);
  if (post) {
    post.comments.push(newComment);
    commentIdCounter++;
  }
  
  return newComment;
}

export async function checkHealth(): Promise<boolean> {
  await delay(100);
  return true; // Always return true for mock backend
}