// Mock backend configuration
export const API_BASE_URL = 'http://localhost:8000/api';

// For production, you can update this or use environment variables
// export const API_BASE_URL = 'https://your-api.vercel.app/api';