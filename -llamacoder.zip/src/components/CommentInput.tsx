import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { MessageCircle } from 'lucide-react';
import { Comment } from '../types';
import { formatDateAgo } from '../lib/utils';
import { useToast } from './ToastProvider';

interface CommentInputProps {
  postId: string;
  comments: Comment[];
  onAddComment: (postId: string, text: string) => Promise<boolean>;
}

export function CommentInput({ postId, comments, onAddComment }: CommentInputProps) {
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!text.trim()) {
      toast({
        title: 'Empty comment',
        description: 'Please write something before posting',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    
    try {
      const success = await onAddComment(postId, text.trim());
      if (success) {
        setText('');
      }
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to post comment',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add a comment..."
          className="flex-1"
        />
        <Button type="submit" disabled={submitting}>
          {submitting ? 'Posting...' : 'Post'}
        </Button>
      </form>

      {/* Comments List */}
      {comments.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
            <MessageCircle className="w-4 h-4" />
            <span>Comments ({comments.length})</span>
          </div>
          
          <div className="space-y-2">
            {comments.map(comment => (
              <div key={comment.id} className="bg-gray-50 rounded-lg p-3">
                <p className="text-gray-800 text-sm">{comment.text}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {formatDateAgo(comment.createdAt)}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}