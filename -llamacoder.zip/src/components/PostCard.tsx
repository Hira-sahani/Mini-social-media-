import React, { useState } from 'react';
import { Post } from '../types';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { MessageCircle, Clock, Send } from 'lucide-react';

interface PostCardProps {
  post: Post;
  onAddComment: (postId: string, text: string) => Promise<void>;
}

export function PostCard({ post, onAddComment }: PostCardProps) {
  const [commentText, setCommentText] = useState('');
  const [commenting, setCommenting] = useState(false);

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!commentText.trim()) {
      alert('Please write something before commenting');
      return;
    }

    setCommenting(true);
    
    try {
      await onAddComment(post.id, commentText.trim());
      setCommentText('');
    } catch (error) {
      // Error is handled by parent component
    } finally {
      setCommenting(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return `${Math.floor(diffMins / 1440)}d ago`;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Image */}
      <div className="aspect-video bg-gray-100">
        <img
          src={post.imageUrl}
          alt={post.altText}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Caption */}
        {post.caption && (
          <p className="text-gray-800 mb-3">{post.caption}</p>
        )}

        {/* Metadata */}
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{formatTimeAgo(post.createdAt)}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="w-4 h-4" />
            <span>{post.comments.length} comments</span>
          </div>
        </div>

        {/* Comments Section */}
        <div className="border-t border-gray-100 pt-4">
          {/* Comment Form */}
          <form onSubmit={handleAddComment} className="flex gap-2 mb-4">
            <Textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Add a comment..."
              rows={1}
              className="resize-none flex-1"
              disabled={commenting}
            />
            <Button
              type="submit"
              size="sm"
              disabled={!commentText.trim() || commenting}
              className="px-3"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>

          {/* Comments List */}
          {post.comments.length > 0 && (
            <div className="space-y-3">
              {post.comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-full flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-800">{comment.text}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatTimeAgo(comment.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}