import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Upload, X } from 'lucide-react';

interface PostFormProps {
  onSubmit: (file: File, caption: string, altText: string) => Promise<void>;
  disabled?: boolean;
}

export function PostForm({ onSubmit, disabled }: PostFormProps) {
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState('');
  const [altText, setAltText] = useState('');
  const [preview, setPreview] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    // Validate file type
    if (!selectedFile.type.startsWith('image/')) {
      alert('Please select an image file (JPEG, PNG, etc.)');
      return;
    }

    // Validate file size (5MB max)
    if (selectedFile.size > 5 * 1024 * 1024) {
      alert('Please select an image smaller than 5MB');
      return;
    }

    setFile(selectedFile);
    setPreview(URL.createObjectURL(selectedFile));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      alert('Please select an image to upload');
      return;
    }

    if (!altText.trim()) {
      alert('Please provide alt text for accessibility');
      return;
    }

    setSubmitting(true);
    
    try {
      await onSubmit(file, caption, altText);
      
      // Reset form
      setFile(null);
      setPreview('');
      setCaption('');
      setAltText('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      // Error is handled by parent component
    } finally {
      setSubmitting(false);
    }
  };

  const clearFile = () => {
    setFile(null);
    setPreview('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* File Upload */}
        <div>
          <Label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-2">
            Image
          </Label>
          <div className="relative">
            <input
              ref={fileInputRef}
              type="file"
              id="image"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              disabled={disabled || submitting}
            />
            {!preview ? (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={disabled || submitting}
                className="w-full border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm text-gray-600">Click to upload image</p>
                <p className="text-xs text-gray-500 mt-1">JPEG, PNG up to 5MB</p>
              </button>
            ) : (
              <div className="relative">
                <img
                  src={preview}
                  alt="Preview"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <button
                  type="button"
                  onClick={clearFile}
                  disabled={disabled || submitting}
                  className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Alt Text */}
        <div>
          <Label htmlFor="altText" className="block text-sm font-medium text-gray-700 mb-2">
            Alt Text <span className="text-red-500">*</span>
          </Label>
          <Input
            id="altText"
            type="text"
            value={altText}
            onChange={(e) => setAltText(e.target.value)}
            placeholder="Describe the image for accessibility"
            disabled={disabled || submitting}
            required
          />
        </div>

        {/* Caption */}
        <div>
          <Label htmlFor="caption" className="block text-sm font-medium text-gray-700 mb-2">
            Caption
          </Label>
          <Textarea
            id="caption"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Write a caption..."
            rows={3}
            disabled={disabled || submitting}
          />
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={disabled || submitting || !file}
          className="w-full"
        >
          {submitting ? 'Uploading...' : 'Create Post'}
        </Button>
      </form>
    </div>
  );
}