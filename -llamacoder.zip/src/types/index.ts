export interface Comment {
  id: string;
  text: string;
  createdAt: string;
}

export interface Post {
  id: string;
  imageUrl: string;
  caption: string;
  altText: string;
  createdAt: string;
  comments: Comment[];
}