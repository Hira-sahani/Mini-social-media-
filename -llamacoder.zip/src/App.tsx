import React, { useState, useEffect } from 'react';
import { PostForm } from './components/PostForm';
import { PostCard } from './components/PostCard';
import { SkeletonPost } from './components/SkeletonPost';
import { getPosts, createPost, addComment, checkHealth } from './lib/api';
import { Post } from './types';
import { Toaster } from './components/ui/toaster';
import { useToast } from './hooks/use-toast';
import { ImagePlus, WifiOff, AlertTriangle } from 'lucide-react';

function App() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [initialized, setInitialized] = useState(false);
  const { toast } = useToast();

  // Initialize app
  useEffect(() => {
    const initializeApp = async () => {
      try {
        const healthy = await checkHealth();
        setIsOnline(healthy);
        if (healthy) {
          await loadPosts(1, true);
        } else {
          setError('Backend is currently unavailable. Please try again later.');
        }
      } catch (err) {
        console.error('Initialization error:', err);
        setIsOnline(false);
        setError('Failed to connect to backend. Please try again later.');
      } finally {
        setInitialized(true);
      }
    };
    
    initializeApp();
  }, []);

  const loadPosts = async (pageNum: number, replace = false) => {
    if (loading || !hasMore || !isOnline) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const newPosts = await getPosts(pageNum, 5);
      
      if (newPosts.length === 0) {
        setHasMore(false);
      } else {
        setPosts(prev => replace ? newPosts : [...prev, ...newPosts]);
        setPage(pageNum + 1);
        
        // If we got fewer posts than requested, we've reached the end
        if (newPosts.length < 5) {
          setHasMore(false);
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load posts';
      setError(errorMessage);
      toast({
        title: "Error loading posts",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Infinite scroll
  useEffect(() => {
    if (!isOnline || !initialized) return;
    
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          loadPosts(page);
        }
      },
      { threshold: 0.1 }
    );

    const sentinel = document.getElementById('scroll-sentinel');
    if (sentinel) observer.observe(sentinel);

    return () => {
      if (sentinel) observer.unobserve(sentinel);
    };
  }, [hasMore, loading, page, isOnline, initialized]);

  const handleCreatePost = async (file: File, caption: string, altText: string) => {
    if (!isOnline) {
      throw new Error('Cannot create post while offline');
    }
    
    setUploading(true);
    
    try {
      const newPost = await createPost(file, caption, altText);
      setPosts(prev => [newPost, ...prev]);
      toast({
        title: "Success!",
        description: "Your post has been created.",
      });
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create post';
      toast({
        title: "Upload failed",
        description: errorMessage,
        variant: "destructive",
      });
      throw new Error(errorMessage);
    } finally {
      setUploading(false);
    }
  };

  const handleAddComment = async (postId: string, text: string) => {
    if (!isOnline) {
      throw new Error('Cannot add comment while offline');
    }
    
    try {
      const newComment = await addComment(postId, text);
      setPosts(prev => prev.map(post => 
        post.id === postId 
          ? { ...post, comments: [...post.comments, newComment] }
          : post
      ));
      toast({
        title: "Comment added",
        description: "Your comment has been posted.",
      });
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to add comment';
      toast({
        title: "Failed to add comment",
        description: errorMessage,
        variant: "destructive",
      });
      throw new Error(errorMessage);
    }
  };

  const retryConnection = async () => {
    try {
      const healthy = await checkHealth();
      setIsOnline(healthy);
      if (healthy) {
        setError(null);
        await loadPosts(1, true);
        toast({
          title: "Connected",
          description: "Backend is now online.",
        });
      } else {
        toast({
          title: "Still offline",
          description: "Backend is still unavailable. Please try again later.",
          variant: "destructive",
        });
      }
    } catch (err) {
      setIsOnline(false);
      toast({
        title: "Connection failed",
        description: "Could not connect to backend.",
        variant: "destructive",
      });
    }
  };

  // Show loading state during initialization
  if (!initialized) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Mini Social...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster />
      
      {/* Connection Status Banner */}
      {!isOnline && (
        <div className="bg-red-50 border-b border-red-200 px-4 py-2">
          <div className="max-w-2xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2 text-red-700">
              <WifiOff className="w-4 h-4" />
              <span className="text-sm font-medium">Backend offline</span>
            </div>
            <button
              onClick={retryConnection}
              className="text-sm text-red-600 hover:text-red-800 underline"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Mini Social</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        {/* Upload Form */}
        <section className="mb-8">
          <PostForm onSubmit={handleCreatePost} disabled={uploading || !isOnline} />
        </section>

        {/* Error State */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <p className="text-red-800 font-medium">{error}</p>
                <button 
                  onClick={() => loadPosts(1, true)}
                  className="mt-2 text-sm text-red-600 hover:text-red-800 underline"
                >
                  Try again
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Posts Feed */}
        <section className="space-y-6">
          {posts.length === 0 && !loading && !error && isOnline && (
            <div className="text-center py-12">
              <ImagePlus className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-700 mb-2">No posts yet</h2>
              <p className="text-gray-500">Upload your first image to get started!</p>
            </div>
          )}

          {posts.map(post => (
            <PostCard 
              key={post.id} 
              post={post} 
              onAddComment={handleAddComment}
            />
          ))}

          {/* Loading Skeleton */}
          {loading && (
            <>
              <SkeletonPost />
              <SkeletonPost />
            </>
          )}

          {/* Scroll Sentinel */}
          {hasMore && <div id="scroll-sentinel" className="h-4" />}
        </section>
      </main>
    </div>
  );
}

export default App;