# Mini Social - Full Stack Application

A mobile-first, responsive social media feed with image uploads, captions, and comments.

## 🌐 Live Demo

- **Frontend**: https://mini-social.vercel.app
- **Backend API**: https://mini-social-api.onrender.com
- **API Documentation**: https://mini-social-api.onrender.com/docs

## 🏗 Architecture

### Frontend (React + TypeScript)
- React 18 with TypeScript
- Tailwind CSS + Shadcn UI components
- Native fetch API with error handling
- Infinite scroll with IntersectionObserver
- Mobile-optimized UI

### Backend (FastAPI + MongoDB)
- FastAPI with async support
- MongoDB for data storage
- Image upload with validation
- CORS enabled for frontend
- Automatic API documentation

## 🚀 Features

- ✅ Image upload (JPEG/PNG, max 5MB)
- ✅ Post creation with captions and alt text
- ✅ Infinite scroll feed with pagination
- ✅ Comment system per post
- ✅ Real-time relative timestamps
- ✅ Offline detection and retry
- ✅ Comprehensive error handling
- ✅ Mobile-optimized (44px+ touch targets)
- ✅ Accessibility support

## 🛠 Tech Stack

### Frontend
- **Framework**: React 18 + TypeScript
- **Styling**: Tailwind CSS + Shadcn UI
- **Icons**: Lucide React
- **Build**: Vite
- **Deployment**: Vercel

### Backend
- **Framework**: FastAPI (Python)
- **Database**: MongoDB
- **File Storage**: Local filesystem
- **Deployment**: Render

## 📱 API Endpoints
