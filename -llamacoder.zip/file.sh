npm install
npm run dev