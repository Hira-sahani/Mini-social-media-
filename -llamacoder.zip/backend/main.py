from fastapi import FastAPI, File, UploadFile, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import os
import uuid
from typing import List, Optional
from pydantic import BaseModel
import aiofiles

# Initialize FastAPI app
app = FastAPI(
    title="Mini Social API",
    description="Backend for mini social media app",
    version="1.0.0"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.vercel.app", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB connection
MONGODB_URL = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
client = MongoClient(MONGODB_URL)
db = client.mini_social

# Create uploads directory
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Serve static files
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Pydantic models
class Comment(BaseModel):
    id: str
    text: str
    createdAt: str

class Post(BaseModel):
    id: str
    imageUrl: str
    caption: str
    altText: str
    createdAt: str
    comments: List[Comment]

class CommentCreate(BaseModel):
    text: str

# Helper functions
def serialize_post(post_doc) -> Post:
    return Post(
        id=str(post_doc["_id"]),
        imageUrl=f"/uploads/{post_doc['filename']}",
        caption=post_doc.get("caption", ""),
        altText=post_doc.get("altText", ""),
        createdAt=post_doc["createdAt"].isoformat(),
        comments=[
            Comment(
                id=str(comment["_id"]),
                text=comment["text"],
                createdAt=comment["createdAt"].isoformat()
            )
            for comment in post_doc.get("comments", [])
        ]
    )

# API Routes
@app.post("/api/posts", response_model=Post)
async def create_post(
    image: UploadFile = File(...),
    caption: str = "",
    altText: str = ""
):
    # Validate file type
    if not image.content_type.startswith("image/"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File must be an image"
        )
    
    # Validate file size (5MB limit)
    if image.size and image.size > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Image must be smaller than 5MB"
        )
    
    # Generate unique filename
    file_extension = image.filename.split(".")[-1] if "." in image.filename else "jpg"
    unique_filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = os.path.join(UPLOAD_DIR, unique_filename)
    
    # Save file
    async with aiofiles.open(file_path, 'wb') as f:
        content = await image.read()
        await f.write(content)
    
    # Create post document
    post_doc = {
        "filename": unique_filename,
        "caption": caption,
        "altText": altText,
        "createdAt": datetime.utcnow(),
        "comments": []
    }
    
    # Insert into MongoDB
    result = db.posts.insert_one(post_doc)
    post_doc["_id"] = result.inserted_id
    
    return serialize_post(post_doc)

@app.get("/api/posts", response_model=List[Post])
async def get_posts(page: int = 1, limit: int = 5):
    skip = (page - 1) * limit
    
    # Fetch posts with pagination, sorted by newest first
    posts_cursor = db.posts.find({}).sort("createdAt", -1).skip(skip).limit(limit)
    posts = []
    
    async for post_doc in posts_cursor:
        posts.append(serialize_post(post_doc))
    
    return posts

@app.post("/api/posts/{post_id}/comments", response_model=Comment)
async def add_comment(post_id: str, comment: CommentCreate):
    # Validate post exists
    if not ObjectId.is_valid(post_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Post not found"
        )
    
    post = db.posts.find_one({"_id": ObjectId(post_id)})
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Post not found"
        )
    
    # Validate comment text
    if not comment.text.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Comment text cannot be empty"
        )
    
    # Create comment
    comment_doc = {
        "text": comment.text.strip(),
        "createdAt": datetime.utcnow()
    }
    
    # Add comment to post
    result = db.posts.update_one(
        {"_id": ObjectId(post_id)},
        {"$push": {"comments": comment_doc}}
    )
    
    if result.modified_count == 0:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to add comment"
        )
    
    # Return the created comment with ID
    comment_doc["_id"] = ObjectId()
    return Comment(
        id=str(comment_doc["_id"]),
        text=comment_doc["text"],
        createdAt=comment_doc["createdAt"].isoformat()
    )

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

# Serve frontend in production
@app.get("/{path:path}")
async def serve_frontend(path: str):
    if os.path.exists(f"static/{path}"):
        return FileResponse(f"static/{path}")
    return FileResponse("static/index.html")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)